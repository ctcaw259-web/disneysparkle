import fs from 'node:fs';
import assert from 'node:assert/strict';
import { DatabaseSync } from 'node:sqlite';
const code=fs.readFileSync(new URL('dist/_worker.js',import.meta.url),'utf8');
const {default:worker}=await import('data:text/javascript;base64,'+Buffer.from(code).toString('base64'));
const sql=new DatabaseSync(':memory:');sql.exec(fs.readFileSync(new URL('dist/family-schema.sql',import.meta.url),'utf8'));
const db={prepare(q){let args=[];return {bind(...a){args=a.map(v=>v instanceof ArrayBuffer?new Uint8Array(v):v);return this},async first(){return sql.prepare(q).get(...args)},async all(){return {results:sql.prepare(q).all(...args)}},async run(){return {meta:{changes:Number(sql.prepare(q).run(...args).changes)}}}}}};
const env={FAMILY_DB:db,SPARKLE_ACCESS_KEY:'test-only'},origin='https://sparkle.example';
const call=(path,method='GET',body,options={})=>worker.fetch(new Request(origin+'/api/family'+path,{method,headers:{Origin:origin,'X-Sparkle-Key':'test-only',...(body?{'Content-Type':'application/json'}:{}),...options.headers},body:body?JSON.stringify(body):undefined}),env,{});
assert.equal((await call('/state','GET',null,{headers:{'X-Sparkle-Key':'wrong'}})).status,401);
assert.equal((await call('/state','POST',{revision:0,state:{}},{headers:{Origin:'https://other.example'}})).status,403);
assert.equal((await call('/state')).status,200);
assert.equal((await call('/state','POST',{revision:0,state:{family:'Walters',favorites:['ride-1'],rideAlerts:{'ride-1':{threshold:45}}}})).status,200);
assert.equal((await call('/state','POST',{revision:0,state:{family:'Stale overwrite'}})).status,409);
assert.equal((await (await call('/state')).json()).state.family,'Walters');
assert.equal((await call('/state','POST',{revision:1,state:{googleAlbum:'javascript:alert(1)'}})).status,400);
assert.equal((await call('/state','POST',{revision:1,state:{rideAlerts:JSON.parse('{"__proto__":{"threshold":45}}')}})).status,400);
assert.equal((await call('/state','POST',{revision:1,state:{family:'x'.repeat(17000)}})).status,400);
for(let i=0;i<21;i++){const id='00000000-0000-0000-0000-'+String(i).padStart(12,'0');const r=await worker.fetch(new Request(origin+'/api/family/photo/'+id,{method:'PUT',headers:{Origin:origin,'X-Sparkle-Key':'test-only','Content-Type':'image/jpeg'},body:new Uint8Array([255,216,255,217])}),env,{});assert.equal(r.status,i<20?200:409)}
const r=await call('/photo/00000000-0000-0000-0000-000000000000');assert.equal(r.headers.get('Cache-Control'),'no-store');assert.equal((await r.arrayBuffer()).byteLength,4);
assert.equal((await (await call('/photos')).json()).photos.length,20);
console.log('Family SQL tests passed: authentication, origin, validation, optimistic conflicts, photo limits, private bytes.');

assert.equal((await call('/photo/00000000-0000-0000-0000-000000000000','DELETE')).status,200);assert.equal((await call('/photo/00000000-0000-0000-0000-000000000000')).status,404);console.log('Shared photo removal verified.');
const badDvc=await call('/state','POST',{revision:1,state:{dvc:[{id:'bad',name:'Bad',year:2026,month:1,current:100,banked:0,borrowed:0,borrowReminder:'',updated:'2026-11-06'}]}});assert.equal(badDvc.status,400);
const tripState={tripSettings:{end:'2027-03-15',mode:'auto',timezone:'America/New_York',parkByDate:{}},dining:[{id:'dining-1',date:'2027-03-10',time:'19:00',name:'Dinner',location:'Resort',status:'Confirmed by family'}],dvc:[{id:'contract-1',name:'Home',year:2026,month:12,current:100,banked:40,borrowed:20,borrowReminder:'',updated:'2026-11-06'}]};
assert.equal((await call('/state','POST',{revision:1,state:tripState})).status,200);const shared=(await(await call('/state')).json()).state;assert.equal(shared.dvc[0].current,100);assert.equal(shared.dining[0].time,'19:00');assert.equal(shared.tripSettings.mode,'auto');console.log('Trip settings, dining and DVC shared-state validation passed.');
