const fs=require('fs'),vm=require('vm'),assert=require('assert');
const noop=()=>{},nodes=new Map();
function node(){return {setAttribute:noop,classList:{toggle:noop,add:noop,remove:noop},innerHTML:'',textContent:'',style:{},dataset:{},prepend:noop,append:noop,remove:noop,querySelectorAll:()=>[],pause(){this.paused=true},play(){this.played=true;return Promise.resolve()},duration:120,currentTime:0};}
for(const id of ['#nav','#breadcrumb','#main','#clock','#toast','#tv','#familyCheckin','#castHelp','#mediaStatus','#cinemaMount','#realVideo','header>div','.brand'])nodes.set(id,node());
const ctx=vm.createContext({console,URL,Date,Intl,Map,Set,Promise,AbortSignal,location:{protocol:'https:',origin:'https://sparkle.example',href:'https://sparkle.example/'},window:{scrollTo:noop},localStorage:{getItem:()=>null,setItem:noop},document:{body:node(),querySelector:s=>nodes.get(s)||null,querySelectorAll:()=>[],addEventListener:noop,createElement:node,head:{append:noop}},setInterval:()=>1,clearInterval:noop,setTimeout:()=>1,cancelAnimationFrame:noop});
const run=s=>vm.runInContext(s,ctx);
for(const f of ['app.js','upgrade.js','experience.js','resort-assets.js','resort-music.js','station.js','songbook.js','connected.js','guide.js','refinements.js'])run(fs.readFileSync('dist/'+f,'utf8').replace("if(!prefs.checkedIn)page='checkin';render();initData();loadVideoTitles();",''));
for(const f of ['plannerMarkup','characterParade','checkin','home','parkPage','resortPage','terrace','multiview','piano','vacation','settings','insights'])assert.ok(run(f+'()').length>100,f);
for(const p of ['home','checkin','resort','piano','settings','multiview'])run(`page='${p}';render()`);
assert.ok(run("spotifySuggestion().url").includes('7MzeWo0EjJDAURZOu5K7oG'));
assert.equal(run('prefs.stationTitle'),'Disney Sparkle');assert.equal(run('prefs.name'),'Guest');
assert.ok(run('settings()').includes('name="stationTitle"'));assert.ok(run('settings()').includes('name="season"'));
assert.ok(run('checkin()').includes('Visiting family'));assert.ok(run('checkin()').includes('name="stationTitle"'));
for(const name of ['Hilton Head','Vero Beach','Grand Californian','Fantasy Springs','Shanghai','Sequoia','Island Tower','Beach Club Villas'])assert.ok(run('resortChoices()').includes(name),name);
assert.notEqual(run("resortIdentity('Animal Kingdom Lodge').photo"),run("resortIdentity('Grand Floridian Resort & Spa').photo"));
assert.equal(run("resortIdentity('Polynesian Village Resort').theme"),'island');
assert.equal(run("seasonNow(new Date('2026-11-05T12:00:00Z'))"),'christmas');
assert.equal(run("seasonNow(new Date('2026-10-10T12:00:00Z'))"),'halloween');
assert.equal(run("seasonNow(new Date('2027-01-06T12:00:00Z'))"),'christmas');
assert.equal(run("seasonNow(new Date('2027-01-07T12:00:00Z'))"),'classic');
assert.ok(run('characterParade()').includes('Tiana'));
run("prefs.family='Walters family';prefs.tripPlan.days=[{id:'one',date:'2027-01-03',park:'<script>alert(1)</script>',priority:'Meet Mickey',notes:'Dinner'}]");
assert.ok(run('familyGreeting()').includes('Walters family'));
assert.ok(!run('plannerMarkup()').includes('<script>alert'));
assert.ok(run('tripText()').includes('Meet Mickey'));
assert.equal(run('HUNT_PAGES.length'),9);
assert.ok(run("guideAnswer('ticket prices')").includes('do not have a live checkout quote'));
assert.ok(run("guideAnswer('tell me everything')").includes('not a connected AI chatbot'));
assert.equal(run("guideAnswer('current weather')"),'weather');
run("live[selected]={source:'Test',data:[{name:'Test Ride',entityType:'ATTRACTION',status:'OPERATING',lastUpdated:new Date().toISOString(),queue:{STANDBY:{waitTime:0}}}]}");
assert.ok(run("guideAnswer('wait times')").includes('0 minutes'));
run("live[selected].data[0].lastUpdated='2000-01-01'");
assert.ok(run("guideAnswer('wait times')").includes('No matching fresh'));


assert.equal(run("spotifyEntity('https://evil.test/playlist/2jHjoxL1G644PvdZ1k3Mw5')"),null);
assert.equal(run("spotifyEntity('https://open.spotify.com/playlist/2jHjoxL1G644PvdZ1k3Mw5').id"),'2jHjoxL1G644PvdZ1k3Mw5');
assert.equal(run("validMediaURL('javascript:alert(1)')"),false);
assert.equal(run("songKey('My Way!')===songKey('my way')"),true);
assert.ok(run("prefs.pianoLibrary.find(t=>songKey(t.name)==='happybirthday').src").includes('FFJ0DdLuui4'));
run("prefs.tagline='<img src=x onerror=alert(1)>'");assert.ok(!run('home()').includes('<img src=x'));
run('prefs.loopStart=-1;prefs.loopEnd=0');assert.equal(run('previewBounds().end'),105);
(async()=>{
run("prefs.loopStart=10;prefs.loopEnd=20;prefs.loopMedia='https://example.org/loop.mp4';playMode='preview'");await run('mountCinema()');const v=nodes.get('#realVideo');assert.equal(v.muted,true);v.onloadedmetadata();assert.equal(v.currentTime,10);v.currentTime=21;v.ontimeupdate();assert.equal(v.currentTime,10);
run("prefs.fullMedia='https://example.org/full.mp4';playMode='full'");await run('mountCinema()');assert.equal(v.muted,false);v.onended();assert.equal(run('playMode'),'preview');
let opts;ctx.window.YT={Player:function(id,o){opts=o;return {destroy:noop}}};run("prefs.loopMedia='';prefs.fullMedia='';playMode='preview'");await run('mountCinema()');assert.equal(opts.playerVars.origin,'https://sparkle.example');opts.events.onError({data:153});assert.ok(nodes.get('#mediaStatus').textContent.includes('153'));
ctx.location.protocol='file:';await run('mountCinema()');assert.ok(nodes.get('#mediaStatus').textContent.includes('local-file'));ctx.location.protocol='https:';
// Selective integrations: favorite resorts, contextual characters, real melody notes.
assert.ok(run("matchingResorts('Polynesian').length")>0);run("prefs.favoriteResorts=['Yacht Club Resort']");assert.equal(run("matchingResorts()[0]"),'Yacht Club Resort');assert.equal(run("resortPianoStyle('Grand Floridian Resort & Spa')"),'ragtime');assert.equal(run("resortPianoStyle('Polynesian Village Resort')"),'hawaiian');assert.ok(run("characterMoment('parks')").includes('Donald'));assert.ok(run("piano()").includes('data-melody'));assert.ok(run("settings()").includes('showCharacters'));
run("var notes=[];LOUNGE.note=(m)=>notes.push(m);loungeAC={currentTime:0};LOUNGE.on=true;LOUNGE.next=.1;LOUNGE.step=0;LOUNGE.bar=0;melody=PDSONGS[0];melodyPosition=0;LOUNGE.tick()");assert.ok(run('notes.includes(72)'));run("LOUNGE.on=false;melody=null;loungeAC=null");
// Only an actual PLAYING event marks a request playing; enqueue/load isn't success.
nodes.set('#pianoAudioMount',node());nodes.set('#requestStatus',node());run("page='piano';activeRequest={name:'My Way',status:'Queued'}");await run("playTrack('my-way')");assert.equal(run('activeRequest.status'),'Loading recording');opts.events.onStateChange({data:1});assert.equal(run('activeRequest.status'),'Playing');opts.events.onError({data:101});assert.ok(run('activeRequest.status').includes('Unavailable'));
// Multiview surfaces upstream errors with an actionable message.
nodes.set('#multi-status-0',node());nodes.set('#multi-0',node());run("page='multiview';prefs.streams[0]={name:'Test',url:'https://www.youtube.com/watch?v=F4JN99sigRs'}");await run('startMulti(0)');opts.events.onError({data:100});assert.ok(nodes.get('#multi-status-0').textContent.includes('change source'));
// Automatic park-hours refresh doesn't detach Spotify or replace resort media.
nodes.set('#parkHours',node());run("page='resort';render()");const originalMain=nodes.get('#main').innerHTML;run("selected='another-park';render()");assert.equal(nodes.get('#main').innerHTML,originalMain);
console.log('PASS: v4 screens, neutral defaults, personalization fields, resort catalog/images, seasonal dates, input validation/escaping, direct preview loop/full return, YouTube origin/error, real request state transitions, uninterrupted resort refresh.');
})().catch(e=>{console.error(e);process.exitCode=1});
