const fs=require('fs'),vm=require('vm'),assert=require('assert');
const noop=()=>{},nodes=new Map();
function node(){return {setAttribute:noop,classList:{toggle:noop,add:noop,remove:noop},innerHTML:'',textContent:'',style:{},dataset:{},prepend:noop,after:noop,append:noop,remove:noop,querySelectorAll:()=>[],pause(){this.paused=true},play(){this.played=true;return Promise.resolve()},duration:120,currentTime:0};}
for(const id of ['#feedHealth','#nav','#breadcrumb','#main','#clock','#toast','#tv','#familyCheckin','#castHelp','#mediaStatus','#cinemaMount','#realVideo','header>div','.brand'])nodes.set(id,node());
const ctx=vm.createContext({console,URL,Date,Intl,Map,Set,Promise,AbortSignal,location:{protocol:'https:',origin:'https://sparkle.example',href:'https://sparkle.example/'},navigator:{onLine:true},window:{scrollTo:noop},localStorage:{getItem:()=>null,setItem:noop},document:{body:node(),querySelector:s=>nodes.get(s)||null,querySelectorAll:()=>[],addEventListener:noop,createElement:node,head:{append:noop}},setInterval:()=>1,clearInterval:noop,setTimeout:()=>1,cancelAnimationFrame:noop});
const run=s=>vm.runInContext(s,ctx);
run(fs.readFileSync('dist/sparkle.js','utf8').replace("bootFamilyTools();if(!prefs.checkedIn)page='checkin';render();initData();loadVideoTitles();",''));

run("prefs.date='2027-03-10';prefs.tripSettings={end:'2027-03-15',mode:'auto',timezone:'America/New_York',parkByDate:{}};");
assert.equal(run("tripIsActive(new Date('2027-03-10T04:00:00Z'))"),false);
assert.equal(run("tripIsActive(new Date('2027-03-10T05:00:00Z'))"),true);
assert.equal(run("tripIsActive(new Date('2027-03-16T03:59:00Z'))"),true);
assert.equal(run("tripIsActive(new Date('2027-03-16T04:00:00Z'))"),false);
run("prefs.tripSettings.mode='off'");assert.equal(run("tripIsActive(new Date('2027-03-11T12:00:00Z'))"),false);
assert.equal(run("dvcDates({year:2026,month:12}).bank"),'2027-07-31');
assert.equal(run("dvcDates({year:2026,month:12}).expires"),'2027-11-30');
assert.equal(run("dvcDates({year:2027,month:3}).expires"),'2028-02-29');
assert.equal(run("dvcBalance({current:10,banked:20,borrowed:30})"),60);
run("prefs.dvc=[{id:'one',name:'Test <script>',year:2027,month:3,current:10,banked:20,borrowed:30,updated:'2026-11-06',borrowReminder:'2027-01-01'}]");
assert.ok(!run('dvcMarkup()').includes('Test <script>'));assert.equal((run('dvcCalendar()').match(/BEGIN:VEVENT/g)||[]).length,3);
assert.ok(run('dvcCalendar()').includes('TRIGGER:-P30D'));assert.ok(run('dvcCalendar()').includes('20280229'));
assert.ok(run('SHARED_FIELDS').includes('dvc'));
console.log('Trip/DVC tests passed: arrival/end inclusivity, Eastern DST, off mode, December year rollover, leap-year expiry, balance, safe markup and reminders.');
